# DO browser extension · v1.5.2

Load unpacked after unzip. Guide: https://www.assembl.co.nz/do/install
