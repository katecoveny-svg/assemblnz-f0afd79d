# DO Mac companion — local development build

A native floating DO companion with the hosted workspace. The orb can be dragged over desktop apps and stays available across Spaces/full-screen apps while DO is running.

## persistence

The development companion now:

- remembers the orb's last screen position between launches;
- remembers whether the floating orb was shown or hidden;
- exposes **Start DO at login** in the menu-bar menu on macOS 13+ using Apple's `SMAppService` login-item API;
- links to the macOS Login Items settings so the user can approve/manage startup directly.

Launch-at-login is opt-in. macOS may require approval in System Settings. The app does not attempt to bypass Login Items controls.

This is still an unsigned/ad-hoc local development companion, not a notarised public Mac release. Public distribution requires Developer ID signing/notarisation and a proper release/update path.

## current interaction model

The floating D opens a compact action menu: **Review selected text**, **Review clipboard**, or **Open workspace**. Opening this menu does not read anything. Dragging only moves the D. Selected-text capture uses existing Accessibility permission; this shortcut does not request a grant. Clipboard review reads copied text only after its button is clicked. A new capture clears the prior native review so a failed capture cannot present old text as the new selection.

The menu brings captured text into the existing native review box. **Add to DO** is still a separate action; provider preparation and its consent remain separate again. If capture fails, the existing web page is not navigated away. Open workspace preserves the existing web page.

The toolbar offers explicit selection capture from the previously active app and review-first paste.

Open DO, choose the app you want to work in, select text, then return to DO and choose **Use selected text** (Show DO see-this). Capture stays in the local review box until you choose **Add to DO**. Use **Review clipboard** to inspect copied text. **Paste reviewed text** inserts only the reviewed content into the chosen editable field. It never presses Return or Send.

The Mac orb, web launcher and Chrome companion are entry points to DO, with different capture capabilities. They do not by themselves share tasks, local storage, browser sessions or permission grants. The `/do/continue` milestone is an explicitly fictional browser-local fixture while durable integration remains closed. See `docs/do-templates/DO-PORTABLE-AGENT.md` for the broader intended direction.

Native-v1 opens `/do/widget?nativeReview=1` as a transient Personal editor. **Check recipient** names the server-verified account in this app’s WebKit session; Chrome sign-in is separate. **Add to DO** binds the exact reviewed text to that account, document and editor revision through a short-lived one-use reservation. An accepted receipt means React committed the text to this editor. It does not mean saved, synced or prepared. There is no legacy unbound handoff fallback.

This transient editor neither restores nor saves the shared browser draft key. Account/scope changes clear prior context and consent and abort preparation; native-origin preparation rechecks the expected owner on the server before provider work. A missing receipt is unknown: check it only in the same document, without replaying text. Navigation requires Clear/new capture/edit before a new offer. Cancellation cannot retract text already committed to the editor.

Accessibility permission is requested only through the labelled **Enable app interaction** button. Each capture and paste checks permission and target application again. Secure text fields are refused. No selected text or clipboard content is automatically read on launch.

## what it does not do yet

The companion does **not** silently record the screen, browse accounts, click arbitrary controls or send messages.

The intended next context-capture step is explicit user-selected screen/window capture using Apple's ScreenCaptureKit system sharing picker. That should:

- be initiated by a clear user action;
- use the system content picker rather than a custom hidden selector;
- show what window/app/display is shared;
- require the normal macOS Screen Recording permission;
- provide a visible stop-sharing state;
- pass only task-relevant frames/context into DO;
- keep capture separate from authority to click/send/buy/submit.

This provides the desired “DO can see what I’m working on” experience without defaulting to continuous invisible surveillance.

Household Floor’s Chrome browser seat (`docs/do-templates/DO-BROWSER-SEAT.md`) is the browser vertical slice today. Mac ScreenCaptureKit should mint the same receipt shape for learn-mode / “show me once” flows. Orb drag is never consent.

## build

Build with the included `build.sh` on macOS with Xcode Command Line Tools:

```bash
./apps/do/macos/build.sh /path/to/output
open /path/to/output/DO.app
```

To create the drag-to-Applications disk image:

```bash
bash apps/do/macos/package.sh /path/to/output
```

The disk image contains DO.app, an Applications shortcut and a short installation guide. The app and menu bar use the shared D identity. Packaging builds in a temporary local folder to prevent synced-folder Finder metadata invalidating the signature, then verifies the signed app and disk image. Only the disk image is written to the chosen output folder.

This verifies packaging, not Apple notarisation or permissions on another Mac. Launch-at-login and cross-app capture still need user-approved on-device testing.

The build targets macOS 13 or later on the build machine’s architecture (Apple silicon for the current installer). An Intel or universal distribution build and testing on older macOS releases remain separate release work.

The build links Cocoa, SwiftUI, WebKit, ApplicationServices and ServiceManagement. Do not disable Gatekeeper or other macOS security controls.

## product direction

The Mac companion is the durable cross-app surface for **do this here, now**. The browser extension should remain the browser-aware sensor/side-panel layer. Both should resolve to the same portable AgentSpec/runtime rather than becoming separate agent systems.

See `docs/DO-OFFICE-ARCHITECTURE.md` for the companion + DO Office model.
