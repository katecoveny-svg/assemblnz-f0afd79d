# DO for Mac · development source · v1.7.0

No notarised public installer. On a Mac with Xcode Command Line Tools: cd macos && bash build.sh ~/Desktop/do-mac-build. Source includes required icon resources. Review macOS microphone/Accessibility prompts yourself.
https://www.assembl.co.nz/do/install#mac
