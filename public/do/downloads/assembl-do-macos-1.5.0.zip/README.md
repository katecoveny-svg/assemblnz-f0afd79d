# DO for Mac · development source · v1.5.0

No notarised public installer. Build with ./macos/build.sh on a Mac.
See https://www.assembl.co.nz/do/install#mac
