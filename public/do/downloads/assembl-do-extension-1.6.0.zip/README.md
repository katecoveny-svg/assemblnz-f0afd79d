# DO browser extension · v1.6.0

Unzip, then Load unpacked. Open the launch panel for signed-in workspace, voice, meetings and TypeSafe. Selection handoff needs an explicit click; no automatic capture or action.
https://www.assembl.co.nz/do/install
