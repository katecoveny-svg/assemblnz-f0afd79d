# DO browser extension · v1.5.0

Load unpacked after unzip. Guide: https://www.assembl.co.nz/do/install
