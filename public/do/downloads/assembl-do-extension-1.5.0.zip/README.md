# DO browser extension · v1.5.0

Load unpacked from this folder after unzip. See https://www.assembl.co.nz/do/install
