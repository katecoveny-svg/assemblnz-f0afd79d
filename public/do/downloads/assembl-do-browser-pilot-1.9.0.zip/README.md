# DO browser pilot

Fixture-only, not a retailer integration. Review the manifest and obtain explicit permission before installing this unpacked package or granting activeTab. No automatic installation. The https://www.assembl.co.nz/* host permission persists until revoked or the extension is removed; it is not limited to two minutes. Only task/read authority expires after two minutes. Only the selected fictional tab and an explicitly chosen first-party Personal DO tab participate. Native Chrome behavior remains unverified. No phone pairing, checkout or payment.
