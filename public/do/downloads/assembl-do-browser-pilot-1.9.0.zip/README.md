# DO browser pilot

Fixture-only, not a retailer integration. Review the manifest and obtain explicit permission before installing this unpacked package or granting activeTab. No automatic installation. Only the selected fictional tab and an explicitly chosen first-party Personal DO tab participate. Native Chrome behavior remains unverified. No phone pairing, checkout or payment.
