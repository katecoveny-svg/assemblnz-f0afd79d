# DO for Mac · development source · v1.5.2

No notarised public installer. Build with ./macos/build.sh on a Mac.
https://www.assembl.co.nz/do/install#mac
