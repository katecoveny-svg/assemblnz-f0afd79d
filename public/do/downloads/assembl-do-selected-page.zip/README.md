# DO selected page

Load this unpacked folder in Chrome. Open a signed-in DO workspace and click this extension toolbar once to bind your owner. Then click the toolbar on the chosen page, choose an image or selected-text snapshot, review it and offer it to the conversation. Access expires after 60 seconds. No page actions or background scanning.
